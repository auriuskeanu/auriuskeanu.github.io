Fantasy World Generation via Voronoi Diagram
Carleton University - COMP4905 Honours Project
Aurius Keanu Medalla #100954645
11 Dec 2017
Coded in Processing 3.3.6

Increment instructions for variable 'n' on prompt are wrong, should be q/a to increment/decrement respectively.

Generating a map randomly generates a set of points to determine each region as well as generates noise and sine waves with random rotation, amplitude, and perodicity, that alters the distance between each point on the map.

n	= # of Voronoi points
N_p	= # of sine waves
A	= Maximum amplitude of sine waves
a	= Noise range
b	= Minimum Noise value