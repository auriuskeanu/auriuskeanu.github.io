import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Main extends PApplet {

/* Program that generates Voronoi Diagrams.
 *
 * '1' to generate map
 * '2' to show prompt while map is generated
 * '3' to toggle borders
 * '4' to show height map
 * '5' to save the image on screen
 * '6' to reset map
 *
 * 'w' to increase sites to generate
 * 's' to decrease
 *
 * I always wanted to learn to play the guitar but the beginning seemed so slow and frustrating
 */
 
int i = 64, state = 0;
Map map;
NumGen generators[];
boolean overlay = false;
int chosenGen;

/* 
 * N_p = number of cosine planes
 * A = max amplitude of waves
 * a = noise multiplier
 * b = noise additive
 */
int N_p = 64, A = 32, a = 12, b = 2;

public void setup() {
  //fullScreen();
  
  frameRate(60);
  noStroke();
  
  generators = new NumGen[5];
  generators[0] = new NoneGen();
  //generators[1] = NoiseGen
  generators[2] = new RandGen(a,b);
  generators[3] = new GaussianGen();
  //generators[4] = CosPlane
  
  chosenGen = 1;
}

public void draw() {
  background(0,59,111);
  
  switch (state) {
    case 0:
      drawPrompt();
      break;
    case 1:
      drawMap();
      break;
  }
}

public void keyPressed() {
  if (key == '1' && state == 0) {
    generators[4] = new CosPlanes(N_p, A, width/20, width*2);
    generators[1] = new NoiseGen(a,b);
    map = new Map(width, height, generators[chosenGen]);
    map.init(i);
    state = 1;
  }
  if (state == 0) {
    if (key == 'q') i++;
    if (key == 'a') i = --i < 1 ? 1 : i;
    if (key == 'w') N_p++;
    if (key == 's') N_p = --N_p < 1 ? 1 : N_p;
    if (key == 'e') A++;
    if (key == 'd') A = --A < 1 ? 1 : A;
    if (key == 'r') a++;
    if (key == 'f') a = --a < 0 ? 0 : a;
    if (key == 't') b++;
    if (key == 'g') b = --b < 0 ? 0 : b;
  }
}
public void keyTyped() {
  if (map != null) {
    if (key == '2') overlay = !overlay;
    if (key == '3') map.toggleOverlay();
    if (key == '4') map.toggleTopography();
    if (key == '5') save("../test.png");
    if (key == '6') reset();
  }
}
public void reset() {
    map = null;
    state = 0;
}
public void drawMap() {
  map.draw();
  if (overlay) {
    drawPrompt();
  }
}
public void drawPrompt() {
  fill(255,255,255);
  textSize(18);
  if (state == 0) {
    textAlign(CENTER);
    text("To increment / decrement;\nA/B = n\nW/S = N_p\nE/D = A\nR/F = a\nT/G = b", width/2, height/4);
  }
  textAlign(LEFT);
  text("1 : Generate map\n2 : Toggle prompt\n3 : Toggle borders\n4 : Toggle topography\n5 : Save image\n6 : Reset map\nEsc to escape", 2, height-18*10);
  String s = "n = " + Integer.toString(i) +
             ", N_p = " + Integer.toString(N_p) + ", A = " + Integer.toString(A) +
             ", a = " + Integer.toString(a) + ", b = " + Integer.toString(b);
  text(s, 2, height-18*12);
}
//Implementation of a lattice graph specialized for this thing


class Lattice {
  public Vertex[][] vertices;
  float maxAltitude;
  
  Lattice(int w, int h, NumGen gen) {
    vertices = new Vertex[w][h];
    maxAltitude = 0;
    
    for (int i = 0; i < w; i++) {
      for (int k = 0; k < h; k++) {
        vertices[i][k] = new Vertex(i, k);
        if (vertices[i][k].altitude > maxAltitude) maxAltitude = vertices[i][k].altitude;
      }
    }
    
    for (int i = 0; i < w; i++) {
      for (int k = 0; k < h; k++) {
        if (i != 0 && vertices[i][k].edges[3] == null) {//west
          vertices[i][k].edges[1] = new Edge(gen.generate(i,k), vertices[i][k], vertices[i-1][k]);
          vertices[i-1][k].edges[1] = vertices[i][k].edges[3];
        }
        if (i != w-1 && vertices[i][k].edges[1] == null) {//east
          vertices[i][k].edges[1] = new Edge(gen.generate(i,k), vertices[i][k], vertices[i+1][k]);
          vertices[i+1][k].edges[3] = vertices[i][k].edges[1];
        }
        if (k != 0 && vertices[i][k].edges[0] == null) {//north
          vertices[i][k].edges[0] = new Edge(gen.generate(i,k), vertices[i][k], vertices[i][k-1]);
          vertices[i][k-1].edges[2] = vertices[i][k].edges[0];
        }
        if (k != h-1 && vertices[i][k].edges[2] == null) {//south
          vertices[i][k].edges[2] = new Edge(gen.generate(i,k), vertices[i][k], vertices[i][k+1]);
          vertices[i][k+1].edges[0] = vertices[i][k].edges[2];
        }
      }
    }
    println("Lattice generated");
  }
  
  public Vertex closestNeighbor(int inX, int inY) {
    Vertex v = vertices[inX][inY];
    ArrayList<Edge> list = new ArrayList<Edge>();
    for (Edge e : v.edges) {
      if (e != null) list.add(e);
    }
    Vertex u = list.get(0).a;
    Vertex w = list.get(0).b;
    return v == u ? u : w;
  }
  
  /* Returns true if a neighboring vertex has a different site
   * This is for drawing the region borders
   */
  public boolean neighboring(int i, int j) {
    if (i != 0) {
      if (vertices[i][j].site != vertices[i-1][j].site) return true;
      if (j != 0) {
        if (vertices[i][j].site != vertices[i-1][j-1].site) return true;
      }
      else if (j != vertices[i].length-1) {
        if (vertices[i][j].site != vertices[i-1][j+1].site) return true;
      }
    }
    else if (i != vertices.length-1) {
      if (vertices[i][j].site != vertices[i+1][j].site) return true;
      if (j != 0) {
        if (vertices[i][j].site != vertices[i+1][j-1].site) return true;
      }
      else if (j != vertices[i].length-1) {
        if (vertices[i][j].site != vertices[i+1][j+1].site) return true;
      }
    }
    else if (j != 0) {
      if (vertices[i][j].site != vertices[i][j-1].site) return true;
    }
    else if (j != vertices[i].length-1) {
      if (vertices[i][j].site != vertices[i][j+1].site) return true;
    }
    return false;
  }
}

class Vertex {  //Node class for lattice graph
  public VoronoiSite site, kingdom;
  int x, y;
  float distance, kDistance, altitude; //distance to an associated site
  public Edge[] edges; // 0, 1, 2, 3 >> norht, east, south, west
  public Vertex(int inX, int inY) {
    distance = kDistance = 0;
    x = inX;
    y = inY;
    site = kingdom = null;
    edges = new Edge[4];
    altitude = generators[4].generate(x,y) + generators[1].generate(x,y);
  }
  public void setSite(VoronoiSite inSite) { this.site = inSite; }
}

class Edge implements Comparator<Edge>, Comparable<Edge> {
  public float weight;
  public Vertex a, b;
  public Edge(float w, Vertex u, Vertex v) { weight = w; a = u; b = v; }
  
  public int compareTo(Edge v) {
    return weight < v.weight ? -1 : weight == v.weight ? 0 : 1;
  }
  public int compare(Edge u, Edge v) {
    return u.weight < v.weight ? -1 : u.weight == v.weight ? 0 : 1;
  }
}
//Class definition for a map

class Map {
  VoronoiSite[] sites, kingdoms;
  private Lattice lattice;
  PImage map;
  PImage heightMap;
  PImage borders;
  int mapWidth, mapHeight;
  boolean overlay, topoView;
  
  public Map(int w, int h, NumGen generator) {
    mapWidth = w; mapHeight = h;
    lattice = new Lattice(w, h, generator);
    overlay = true;
    topoView = false;
  }
  public void init(int i) { 
    generateSites(i);
    frontierRegions();
    //calculateRegions();
    for (int j = 0; j < mapWidth; j++) {
      for (int k = 0; k < mapHeight; k++) {
        if (j == 0 || k == 0 || j == mapWidth-1 || k == mapHeight-1) lattice.vertices[j][k].site.setWater();
      }
    }
    borders = createImage(mapWidth, mapHeight, ARGB);
    map = createImage(mapWidth, mapHeight, ARGB);
    heightMap = createImage(mapWidth, mapHeight, ARGB);
    for (int j = 0; j < mapWidth; j++) {
      for (int k = 0; k < mapHeight; k++) {
        
        map.pixels[k*mapHeight + j] = (lattice.vertices[j][k].site.water() ? color(0,59,111,255) : color(0,100,0,255));
        heightMap.pixels[k*mapHeight + j] = color(((lattice.vertices[j][k].altitude) / lattice.maxAltitude)*255);//Was doing [j*mapWidth + k] instead of current 26/09
        borders.pixels[k*mapHeight + j] = lattice.neighboring(j,k) ? color(0,0,0,255) : color(0,0,0,0);
      }
    }
  }
  
  public void draw() {
    if (sites == null) return;
    image(map,0,0);
    if (topoView) image(heightMap, 0, 0);
    if (overlay) {
     // image(image,0,0);
      image(borders,0,0);
      for (int i = 0; i < sites.length; i++) {
        fill(sites[i].colour());
        ellipse(sites[i].x(), sites[i].y(),5,5);
      }
    }
    fill(0,0,0);
  }
  
  private void generateSites(int i) {
    sites = new VoronoiSite[i];
    for (int k = 0; k < i; k++) {
      float x = random(width);
      float y = random(height);
      sites[k] = new VoronoiSite((int)x, (int)y, color(random(255),random(255),random(255), 255));
    }
  }
  
  private void frontierRegions() {  //somehow turned into a manhattan distance voronoi region generator
    ArrayDeque<Vertex> frontier = new ArrayDeque<Vertex>();
    for (VoronoiSite site : sites) {
      Vertex v = lattice.vertices[site.x][site.y];
      v.setSite(site);
      frontier.add(v);
    }
    while (!frontier.isEmpty()) {
      Vertex v = frontier.remove();
      for (Edge e : v.edges) {
        if (e != null) {
          Vertex x = (v == e.a ? e.b : e.a);
          float sloped = abs(x.altitude - v.altitude);
          if (x.site == null || (v.distance +sloped < x.distance)) {
            x.distance = v.distance + sloped;
            x.setSite(v.site);
            frontier.add(x);
          }
        }
      }
    }
  }
  
  private void calcKingdoms() {  //create kingdom sites using K-means clustering
    class Tuple {
      VoronoiSite x, y;
    }
    ArrayList<VoronoiSite> landSites = new ArrayList<VoronoiSite>();
    for (VoronoiSite site : sites) {
      if (!site.water) landSites.add(site);
    }
    Tuple[] tuples = new Tuple[landSites.size()];
    for (int i = 0; i < landSites.size(); i++) tuples[i].x = landSites.get(i); 
    int kDoms = round(sqrt(landSites.size()));
    kingdoms = new VoronoiSite[kDoms];
    for (int i = 0; i < kDoms; i++) { //initialize kingdom sites
      int x, y;
      do {
        x = (int)random(width);
        y = (int)random(height);
      } while (lattice.vertices[x][y].site.water);
      kingdoms[i] = new VoronoiSite(x,y, color(random(255),random(255),random(255)));
    }
    Boolean change = false;
    do {
      change = false;
      for (int i = 0; i < landSites.size(); i++) {
        VoronoiSite current = kingdoms[0];
        for (VoronoiSite kingdom : kingdoms) { //Set landSite to nearest kingdom, Euclidean distance
          if (dist(landSites.get(i).x(), landSites.get(i).y(), kingdom.x(), kingdom.y()) < dist(landSites.get(i).x(),landSites.get(i).y(),current.x(),current.y())) {
            current = kingdom;
            change = true;
          }
        }
        tuples[i].y = current;
      }
      //Calculate new kingdom location from averages
      if (change) {
        for (int i = 0; i < kingdoms.length; i++) {
          int nuX, nuY, num; nuX = nuY = num = 0;
          for (Tuple tuple : tuples) {
            if (tuple.y == kingdoms[i]) {
              nuX += tuple.x.x;
              nuY += tuple.x.y;
              num++;
            }
          }
          kingdoms[i].x = nuX / num;
          kingdoms[i].y = nuY / num;
        }
      }
    } while (change);
  }
  
  private void landRegions() { //Associate land nodes w/ 'kingdom' sites
    ArrayDeque<Vertex> frontier = new ArrayDeque<Vertex>();
    for (VoronoiSite site : kingdoms) {
      Vertex v = lattice.vertices[site.x][site.y];
      if (!v.site.water) v.kingdom = site;
      frontier.add(v);
    }
    while (!frontier.isEmpty()) {
      Vertex v = frontier.remove();
      for (Edge e : v.edges) {
        if (e != null) {
          Vertex x = (v == e.a ? e.b : e.a);
          float sloped = abs(x.altitude - v.altitude);
          if (x.site == null || (v.kDistance + sloped < x.kDistance)) {
            x.kDistance = v.kDistance + sloped;
            if (!x.site.water) x.kingdom = v.kingdom;
            frontier.add(x);
          }
        }
      }
    }
  }
  
  public void toggleOverlay() { overlay = !overlay; }
  public void toggleTopography() { topoView = !topoView; }
}
//classes to encapsulate number generation

abstract class NumGen {
 public abstract float generate(int x, int y); 
}

class NoneGen extends NumGen {
  public float generate(int x,int y) {
    return 0;
  }
}

class NoiseGen extends NumGen {
  int a, b;
  
  public NoiseGen(int a, int b) {
    this.a = a;
    this.b = b;
  }
  public NoiseGen() {
    this(1, 0);
  }
  
  public float generate(int x, int y) {
    return a*noise(x, y) + b;
  }
}

class RandGen extends NumGen {
  int a, b;
  public RandGen(int a, int b) { this.a = a; this.b = b; }
  public float generate(int x, int y) {
    return random(a)+b;
  }
}

class GaussianGen extends NumGen {
 public float generate(int x, int y) {
   return abs(randomGaussian())*10;
 }
}

class CosPlanes extends NumGen {
  float[] rots, amps, pers, offset;        //rots = rotation in radians, ampls = amplitude, pers = cosine wave period multiplier
  public CosPlanes(int n, int a, float p_f, float p_c) {
    rots = new float[n];
    amps = new float[n];
    pers = new float[n];
    offset = new float[n];
    for (int i = 0; i < n; i++) {
      rots[i] = random(PI);
      amps[i] = random(1, a);
      pers[i] = TWO_PI / random(p_f, p_c);
      offset[i] = random(PI/2);
    }
  }
  
  public float generate(int x, int y) {
    float returnee = 0;
    for (int i = 0; i < rots.length; i++) {
      returnee += amps[i]*cos(pers[i]*(x*cos(rots[i]) - y*sin(rots[i]))- offset[i]) + amps[i];
    }
    return returnee > 0 ? returnee : -1*returnee;
  }
}
//Class definition for a Voronoi Site

class VoronoiSite {
  //stuff to add
  private int x, y;
  private int colour;
  private boolean water;
  
  public VoronoiSite(int inX,int inY, int inColor) {
    x = inX;
    y = inY;
    colour = inColor;
    water = false;
  }
  
  public int x() { return x; }
  public int y() { return y; }
  public int colour() { return colour; }
  public boolean water() { return water; }
  public void setWater() { water = true; }
  
}
  public void settings() {  size(1000,1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Main" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
